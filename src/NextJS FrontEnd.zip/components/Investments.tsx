export default function Investments() {
    return <div className="text-2xl font-bold">Investments Page</div>
  }