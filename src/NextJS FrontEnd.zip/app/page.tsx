import PersonalBankingApp from "@/app/App";


export default function Home() {
  return (
    <>
    <PersonalBankingApp />
    </>  
  );
}
